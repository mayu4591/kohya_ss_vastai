# noqa: C801
__version__ = "0.0.31+eb3ea378.d20250621"
